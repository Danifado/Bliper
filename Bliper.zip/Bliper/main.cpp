#include <string>
#include <iostream>
#include <fstream>
#include "HashBliper(1).hpp"
using namespace std;

int main() {

  HashMap Bliper(-1);

  Bliper.read_text("House.dat"); // Archivo con base de datos
  Bliper.read_text("Waste.dat"); // Cosas que se consumieron
  Bliper.read_text("Bought.dat"); // Cosas que se agregaron
  Bliper.user_info("House.dat"); // Archivo con base de datos después de las modificaciones

  return 0;
}
