#include <string>
#include <iostream>
#include <fstream>
#include "HashBliper(1).hpp"
using namespace std;

int main() {
  /*char List[26]= {'a', 'b', 'c', 'd', 'e', 'f', 'g'
  ,'h','i','j','k','l','m','n','o','p','q'
  ,'r','s','t','u','v','w','x','y','z'};*/
  HashMap Bliper(-1);

  Bliper.read_text("House.dat"); // Archivo con base de datos
  Bliper.read_text("Waste.dat"); // Cosas que se consumieron
  Bliper.read_text("Bought.dat"); // Cosas que se agregaron
  // Bliper.buy_list("Buy_list.dat");
  Bliper.user_info("House.dat");

  return 0;
}
