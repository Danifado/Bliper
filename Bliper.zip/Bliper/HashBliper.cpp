#include "HashBliper(1).hpp"

HashMap::HashMap(float var){
  notfound = var;
  nCtainers = CONTAINERS_SIZE;
  ctainers = new Cell*[nCtainers];
  for(int i = 0 ; i < nCtainers ; i++){
    ctainers[i] = nullptr;
  }
  count = 0;
}
HashMap::~HashMap(){
  clear_hash();
}

void HashMap::clear_hash(){
  for(int i = 0 ; i < nCtainers ; i++){
    Cell *ptr = ctainers[i];
    while (ptr != nullptr){
      Cell *oldptr = ptr;
      ptr = ptr -> link;
      delete oldptr;
      }
    }
  count = 0;
}

int HashMap::size(){
  return count;
}


bool HashMap::empty_hash(){
 return count == 0;
}
bool HashMap::empty_fhash(int index){
  if(ctainers[index]==nullptr){
    return true;
  }else{
    return false;
  }
}

//toca cambiarlo
float HashMap::get_hash(string key){
  int index = Hash_Code(key);
  Cell *ptr = ctainers[index];
  while(ptr != nullptr && key != ptr->key){
    ptr = ptr ->link;
  }
  return ptr->value;
}

void HashMap::insert(string key ,float value){
  unsigned int index = Hash_Code(key);
  Cell *ptr = find_cell(index,key);

  if(ptr == nullptr){
    // cout << "ahi esta vacio " << endl;
    Cell *pt = new Cell;
    pt->key = key;
    pt->link = ctainers[index];
    ctainers[index] = pt;
    count++;
    if((pt->value + value)<= 0.0)
      pt->value = 0.0;
    else pt->value += value;
  }else
  if((ptr->value + value)<= 0.0)
    ptr->value = 0.0;
  else ptr->value += value;
}

void HashMap::remove(string key){
  unsigned int index = Hash_Code(key);
  count -- ;
  Cell *ptr = ctainers[index] , *pr = nullptr;
  while(ptr!=nullptr){
    if(key == ptr->key){
      if(pr==nullptr){
        ctainers[index]=ptr->link;
        delete ptr;
        break;
      }else{
        pr->link = ptr->link;
        delete ptr;
        break;
      }
    }else{
      pr=ptr;
      ptr=ptr->link;
    }
  }
}

void HashMap::distribution(const string &filename){
  filebuf fb;
  fb.open(filename, ios::out);
  ostream os(&fb);

  Cell * kv = nullptr;
  unsigned int counter;
  for(int i = 0; i < nCtainers; i++){
    counter = 0;
    kv = ctainers[i];
    while(kv != nullptr){
      counter++;
      kv = kv -> link;
    }
    os << counter <<", ";
  }
  fb.close();
}

void HashMap::user_info(string txt){
  ofstream out_file;
  out_file.open(txt);
  for(unsigned int i = 0; i < 26; i++){
    Cell *temp = ctainers[i];
    while(temp != nullptr){
      if(empty_fhash(i)){
        break;
      }else{
        out_file<< temp->key <<"//"<< temp -> value<<"\n";
      }
      temp = temp -> link;
    }
  }
  out_file.close();
}

void HashMap::read_text(string txt){
  ifstream ifs;
  string line = "";
  ifs.open(txt);
  if(ifs.good()){
    while(!ifs.eof()){
      getline(ifs, line);
        if(line != ""){
        size_t sep = line.find("//");
        string key = line.substr(0,sep);
        float value = stod(line.substr(sep+2));
        insert(key,value);
      }
    }
  }
  ifs.close();
}
