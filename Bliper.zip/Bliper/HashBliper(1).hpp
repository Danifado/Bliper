#ifndef _HashBliper_hpp_
#define _HashBliper_hpp_
#include <string>
#include <iostream>
#include <fstream>
#include <cctype>
using namespace std;

const int CONTAINERS_SIZE = 26;

class HashMap {
private:

  struct Cell {
    float value;
    string key;
    Cell *link;
  };
  Cell **ctainers;
  int nCtainers;
  int count;

  float notfound;

  unsigned int Hash_Code(string key){//good
    char List[26]= {'a', 'b', 'c', 'd', 'e', 'f', 'g'
    ,'h','i','j','k','l','m','n','o','p','q'
    ,'r','s','t','u','v','w','x','y','z'};
    int index_Hash = 0;
    char utl = key[0];
    if(isupper(utl))
      utl = tolower(utl);
    for(int i = 0 ; i < 26 ; i++){
      if(utl == List[i]){
        index_Hash = i;
        return index_Hash;
      }else{
        continue;
      }

    }
    return index_Hash;
  }

  Cell* find_cell(int ctainer, string key){//good
    Cell* cptr = ctainers[ctainer];
    while(cptr != nullptr && key != cptr->key){
      cptr = cptr -> link;
    }
    return cptr;
  }


public:
  HashMap(float var);//good
  ~HashMap();//good

  int size();
  void clear_hash();//good
  void insert(string key , float value);
  void remove(string key);
  float get_hash(string key); // Retornar el valor
  bool empty_hash();//good
  bool empty_fhash(int index);//Lista enlazada vacia
  void distribution(const string &filename);
  void user_info(string txt);
  void read_text(string txt);
  // void buy_list(string txt);
};


#endif //_HashBliper_hpp_
