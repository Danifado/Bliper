import pygame, Button, os, menu, menu_2, pyttsx3
from pygame.locals import *

pygame.init()
Width = 1084
Height = 610
Display = pygame.display.set_mode((Width, Height))
pygame.display.set_caption("Bliper")

x =  (-1)
x1 = (-15)
y = (-1)
white = (255,255,255)
Grey1 = (185, 181, 178)
Grey2 = (228, 226, 225)
clock = pygame.time.Clock()
Val = False
Init = pygame.image.load("inicio2.png")
bg = menu.Menu()
Main = pygame.image.load("main1.png")
Main1 = pygame.image.load("main2.png")

def image(imag,x,y):
    Display.blit(imag,(x,y))

Display.fill(Grey1)
image(Init,x,y)
pygame.display.update()
clock.tick(100)
pygame.time.wait(2500)

Bought = Button.Button((250,250,250),235,246, 155, 100, "I bought")
Waste = Button.Button((250,250,250),698, 246, 155, 100, "I ate")
b_read = Button.Button(Grey2, 465, 246, 155, 100, "Read everything", 25)

def voice_you_have(txt):
    dict = read_text(txt)
    engine = pyttsx3.init()
    open_text = open(txt, "r")
    for key in dict.keys():
        voice = "You have " + str(dict[key]) + " of " + key
        print(voice)
        engine.say(voice)
        engine.runAndWait()

def read_text(txt):
    list = {}
    open_text = open(txt, "r")
    a = open_text.readlines()
    for i in a:
        space = "\n"
        if '\n' in i:
            line = (i.replace(space,""))
            sep = line.find("//")
            key = line[:sep]
            value = line[sep+2:]
            if key not in list.keys():
                list[key] = float(value)

    return list

def write_text(dict, txt):
    open_text = open(txt, "w")
    for key in dict.keys():
        elem = key+"//"+str(dict[key])+"\n"
        open_text.write(elem)
    os.startfile(r"C:\Users\Daniel Zárate\Downloads\proyecto\a.exe")
def w_menu():
    screen = pygame.display.set_mode((1084, 610))
    font = pygame.font.Font(None, 32)
    clock = pygame.time.Clock()
    input_box = pygame.Rect(442, 280, 250, 32)
    color_inactive = pygame.Color = (250,250,250)
    color_active = pygame.Color = (255,255,255)
    color = color_inactive
    active = False
    text = ''
    done = False
    bg_ate = menu_2.Menu_2("ate.png")
    exit = Button.Button((250,250,250), 36, 58, 120, 76, "EXIT")
    b_done = Button.Button((250,250,250), 425, 384, 239, 32, "Done")
    dict = {}
    while not done:
        for event in pygame.event.get():
            mouse = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                done = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
                if exit.isOver(mouse):
                    done = True
                    open_text = open("Waste.dat", "w").close()
                if b_done.isOver(mouse):
                    write_text(dict,"Waste.dat")
            if event.type == pygame.MOUSEMOTION:
                if exit.isOver(mouse):
                    exit.color = (255, 0, 0)
                if b_done.isOver(mouse):
                    b_done.color = (211,211,211)
                if not exit.isOver(mouse):
                    exit.color = (250, 250, 250)
                if not b_done.isOver(mouse):
                    b_done.color = (250, 250, 250)
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        sep = text.find("//")
                        key = text[:sep]
                        value = text[sep+2:]
                        if key not in dict.keys():
                            dict[key] = float(value) * -1
                        if key in dict.keys():
                            dict[key] -= float(value)
                        text = ""
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode

        screen.fill((30, 30, 30))
        bg_ate.draw(screen)
        exit.draw(screen)
        b_done.draw(screen)
        txt_surface = font.render(text, True, color)
        width = max(200, txt_surface.get_width()+10)
        input_box.w = width
        screen.blit(txt_surface, (input_box.x+5, input_box.y+5))
        pygame.draw.rect(screen, color, input_box, 2)

        pygame.display.flip()
        clock.tick(30)

def b_menu():
    screen = pygame.display.set_mode((1084, 610))
    font = pygame.font.Font(None, 32)
    clock = pygame.time.Clock()
    input_box = pygame.Rect(442, 280, 250, 32)
    color_inactive = pygame.Color = (250,250,250)
    color_active = pygame.Color = (250,250,250)
    color = color_inactive
    active = False
    text = ''
    done = False
    bg_bought = menu_2.Menu_2("bought.png")
    exit = Button.Button((250,250,250), 924, 60, 120, 75, "EXIT")
    b_done = Button.Button((250,250,250), 445, 354, 200, 80, "Done")
    dict = {}
    while not done:
        for event in pygame.event.get():
            mouse = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                done = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
                if exit.isOver(mouse):
                    done = True
                    open_text = open("Bought.dat", "w").close()
                if b_done.isOver(mouse):
                    write_text(dict,"Bought.dat")
            if event.type == pygame.MOUSEMOTION:
                if exit.isOver(mouse):
                    exit.color = (255, 0, 0)
                if b_done.isOver(mouse):
                    b_done.color = (211,211,211)
                if not exit.isOver(mouse):
                    exit.color = (250, 250, 250)
                if not b_done.isOver(mouse):
                    b_done.color = (250, 250, 250)

            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        sep = text.find("//")
                        key = text[:sep]
                        value = text[sep+2:]
                        if key not in dict.keys():
                            dict[key] = float(value)
                        elif key in dict.keys():
                            dict[key] += float(value)
                        text = ""
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode

        screen.fill((30, 30, 30))
        bg_bought.draw(screen)
        exit.draw(screen)
        b_done.draw(screen)
        txt_surface = font.render(text, True, color)
        width = max(200, txt_surface.get_width()+10)
        input_box.w = width
        screen.blit(txt_surface, (input_box.x+5, input_box.y+5))
        pygame.draw.rect(screen, color, input_box, 2)

        pygame.display.flip()
        clock.tick(30)

def menu(Val):
    while not Val:
        pygame.display.update()
        for event in pygame.event.get():
            mouse = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                Val = False
                pygame.quit()
                quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if Bought.isOver(mouse):
                    b_menu()
                if Waste.isOver(mouse):
                    w_menu()
                if b_read.isOver(mouse):
                    voice_you_have("House.dat")
            if event.type == pygame.MOUSEMOTION:
                if Bought.isOver(mouse):
                    Bought.color = (0,255,0)
                if Waste.isOver(mouse):
                    Waste.color = (0,255,0)
                if not Bought.isOver(mouse):
                    Bought.color = (228, 226, 225)
                if not Waste.isOver(mouse):
                    Waste.color = (228, 226, 225)

        Display.fill(Grey2)
        bg.draw(Display)
        Bought.draw(Display)
        Waste.draw(Display)
        b_read.draw(Display)

#BEG_EXE

menu(Val)

pygame.quit()
quit()
