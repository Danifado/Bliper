import pygame

class Menu_2(pygame.sprite.Sprite):

    def __init__(self, img):
        self.imgs = [pygame.image.load(img),pygame.image.load(img)]
        self.index = 0
        self.move = 2
        self.img = self.imgs[self.index]
    def update(self):
        if self.index > 1:
            self.index = 0
        self.img = self.imgs[self.index]
        self.index += 1

    def draw(self, surface):
        if self.move > 1:
            surface.blit(self.img,(-1,-1))
            self.update()
