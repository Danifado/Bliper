#include <string>
#include <iostream>
#include <fstream>
#include "HashBliper(1).hpp"
using namespace std;



int main() {
  string line = "miel//-7.3";
  size_t sep = line.find("//");
  string key = line.substr(0,sep);
  cout<<key<<"...............\n";

  return 0;
}
